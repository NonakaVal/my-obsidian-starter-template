~~~dataviewjs
<%tp.file.cursor()%>
~~~
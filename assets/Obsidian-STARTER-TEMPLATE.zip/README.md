# Seja bem Vindo ao meu Template Obsidian.

> ⚠️ Está vault é um template -   Não está Padrão do [Obisidian.md](https://obsidian.md/) 

---

> [!Video]- Caso se perca, sobre Os Workspaces
> <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://drive.google.com/file/d/16LoXfq4ySZmYJ8K9RIUcp6sT7Z1b_lnH/preview" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe></div>

> [!Video]- Sobre a Vault e dicas de Personalização
> <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://drive.google.com/file/d/1hHHp22cD4Rh8TneKHf4K1-C2dGpD8MiI/preview" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe></div>


>[!SUMMARY]- Conteúdos
>- [[README#Primeiros Passos |Primeiros Passos ]]
>- [[README#Funcionalidades|Funcionalidades]]
>            - [[README#➕ Criação de notas |➕ Criação de notas ]]
>            - [[README#💭 Daily Captures|💭 Daily Captures]]
>            - [[README#⚡ Templates|⚡ Templates]]
>            - [[README#⌨️ Atalhos de teclado|⌨️ Atalhos de teclado]]
>- [[README#🔌 Lista de Plugins da Comunidade|🔌 Lista de Plugins da Comunidade]]
>- [[README#🆘 Correções de problemas comuns|🆘 Correções de problemas comuns]]



<br>





---
# Primeiros Passos 


 `BUTTON[readme]`   :LiOption:    `BUTTON[workspaces]` 

```meta-bind-button
label: Atalhos
hidden: true
icon: keyboard
class: ""
id: keyboard
style: primary
actions:
  - type: command
    command: obsidian-hotkeys-for-specific-files:X/Assets/_atalhos.md-new-tab
```
 *Leia A apresentação Abaixo para o uso*
# Funcionalidades


#### ➕ Criação de notas 

- `Ctrl + N` para criar uma nova nota – plugin [QuickAdd](https://github.com/chhoumann/quickadd)

![](https://imgur.com/JfpCUix.png)


#### 💭 Daily Captures

> Registros rápidos nas notas diárias

![Imgur](https://imgur.com/AclMjHY.png)

#### ⚡ Templates

![Imgur](https://imgur.com/i8xdCwP.png)



#### ⌨️ Atalhos de teclado

![Imgur](https://imgur.com/SSHbQRZ.png)


<br>

 :LiOption:    `BUTTON[workspaces]` 

---

<br>
<br>
<br>

# 🔌 Lista de Plugins da Comunidade
- **[Auto Link Title](https://obsidian.md/plugins?id=obsidian-auto-link-title)** – Busca automaticamente o título de links da web
- **[Calendar](https://obsidian.md/plugins?id=calendar)** – Visualização em calendário integrada às notas diárias 
- **[Callout Manager](https://obsidian.md/plugins?id=callout-manager)** – Crie e gerencie callouts sem escrever CSS
- **[Dataview](https://obsidian.md/plugins?id=dataview)** – Consulte e organize notas como um banco de dados
- **[Force note view mode](https://obsidian.md/plugins?id=obsidian-view-mode-by-frontmatter)** – Define o modo de visualização e edição das notas pelo frontmatter
- **[Hotkeys for specific files](https://obsidian.md/plugins?id=obsidian-hotkeys-for-specific-files)** – Atalhos personalizados para abrir arquivos específicos 
- **[Iconize](https://obsidian.md/plugins?id=obsidian-icon-folder)** – Adicione ícones personalizados a arquivos, pastas e links
- **[Meta Bind](https://obsidian.md/plugins?id=obsidian-meta-bind-plugin)** – Campos interativos ligados diretamente ao frontmatter
- **[Markdown Tabs](https://obsidian.md/plugins?id=tabs)** – Organize conteúdo em abas dentro das notas
- **[Novel word count](https://obsidian.md/plugins?id=novel-word-count)** – Exiba a contagem de palavras de arquivos, pastas e do vault
- **[Outliner](https://obsidian.md/plugins?id=obsidian-outliner)** – Edição em estilo de lista com atalhos aprimorados
- **[Paste URL into selection](https://obsidian.md/plugins?id=url-into-selection)** – Converte automaticamente o texto selecionado em link
- **[Paste image rename](https://obsidian.md/plugins?id=obsidian-paste-image-rename)** – Renomeia imagens e outros anexos ao adicioná-los ao vault
- **[Periodic Notes](https://obsidian.md/plugins?id=periodic-notes)** – Crie e gerencie notas semanais, mensais e anuais
- **[QuickAdd](https://obsidian.md/plugins?id=quickadd)** – Captura rápida de conteúdo usando comandos, templates e automações
- **[Recent Files](https://obsidian.md/plugins?id=recent-files-obsidian)** – Acesso rápido a notas abertas recentemente
- **[Remember cursor position](https://obsidian.md/plugins?id=remember-cursor-position)** – Lembra a posição do cursor e da rolagem em cada nota
- **[Simple Banner](https://obsidian.md/plugins?id=simple-banner)** – Adicione banners visuais às notas
- **[Style Settings](https://obsidian.md/plugins?id=obsidian-style-settings)** – Ajuste opções de temas, plugins e snippets
- **[Tag Wrangler](https://obsidian.md/plugins?id=tag-wrangler)** – Renomeie, una e gerencie tags em todo o vault
- **[Templater](https://obsidian.md/plugins?id=templater-obsidian)** – Crie templates avançados e automatize a criação de notas



# 🆘 Correções de problemas comuns

- Bugs de sistema e de blocos de plugins.

![[rebuild vault cache.png|600]]

- Snippets de CSS não aplicam: Configurações → Aparência → Snippets de CSS → ative o snippet desejado.

![[snippetss.png|500]]

- Templater não executa: confirme o caminho da pasta de Templates nas configurações do plugin.

---

<br>

 :LiOption:    `BUTTON[workspaces]` 


<br><br><br><br>

```meta-bind-button
label: Começe Aqui (Tópicos em Ordem)
hidden: true
icon: space
class: ""
id: workspaces
style: destructive
actions:
  - type: command
    command: workspaces:load
```

```meta-bind-button
label: README (Leia Me)
hidden: true
icon: info
class: ""
id: readme
style: primary
actions:
  - type: command
    command: obsidian-hotkeys-for-specific-files:README.md-new-tab
```


---



![[Créditos-Atribuições]]
---
collection: "[[Gestão de Conhecimento]]"
---


O **framework ACE** (Atlas, Calendar, Efforts) é um sistema universal para organizar conhecimento, tempo e ação — foi criada por [Nick Milo](https://forum.obsidian.md/t/the-ultimate-folder-system-a-quixotic-journey-to-ace/63483) e se organiza em três áreas principais:

> [!Video]- Framework ACE
> - Apresente Atlas, Calendar e Efforts e o propósito de cada área.
> - Explique o que guardar em cada uma usando exemplos simples.
> - Mostre como conhecimento, tempo e ação se complementam.


- **A – Atlas** → Guarda referências e conhecimento geral. É o “mapa” das suas ideias, conceitos e temas.
- **C – Calendário** → Armazena tudo que está ligado a datas: eventos, prazos, registros cronológicos.
- **E – Esforços** → Contém seus projetos, tarefas e iniciativas que exigem ação.


![img](https://imgur.com/7l2YOi4.png)

    
| Espaço       | Foco         | Dimensão Temporal | Intenção    | Princípio Organizador |
| ------------ | ------------ | ----------------- | ----------- | --------------------- |
| **Atlas**    | Conhecimento | Atemporal         | Compreender | Espaço (relações)     |
| **Calendar** | Tempo        | Temporal          | Focar       | Sequência temporal    |
| **Efforts**  | Ação         | Oportuno          | Agir        | Prioridade/urgência   |

---

<br>

 
```meta-bind-button
label: Seguir para 03 ARC Framework
hidden: false
icon: arrow-right
class: ""
id: workspaces
style: destructive
actions:
  - type: command
    command: workspaces:load
```
